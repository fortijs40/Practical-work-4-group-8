import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Text, View, Image } from 'react-native';

export default function App() {
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('https://newsapi.org/v2/top-headlines?country=lv&apiKey=3a40151deb9b4c718500ee00865b0cbb')
      .then((response) => response.json())
      .then((json) => setData(json.articles))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: "gray", padding:10}}>
    {isLoading ? <ActivityIndicator/> : (
        <FlatList
          data={data}
          keyExtractor={({id}, index) => id}
          renderItem={({item}) => (
            <View style={{marginTop: 5, backgroundColor: "#fff", padding: 14}}>
              <Image source={{ uri: item.urlToImage }} style={{ width: 305, height: 100}} />
              <Text style={{ fontSize: 14, fontWeight: "bold", color: "black" }}>{item.title}</Text>
              <Text style={{ fontSize: 12, color: "black" }}>{item.author}</Text>
            </View>
          )}
        />
    )}
    </View>
  );
}